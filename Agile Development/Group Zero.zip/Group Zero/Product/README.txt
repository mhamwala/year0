Please run the main menu hub to access all the games.
Please also extract the files from the Zip as the Hub wont be able to find them otherwise.

If the Main Menu Hub still cant find the games, please run them seperatly.

The Games_list.txt contains all of the games that should be 
in this library.